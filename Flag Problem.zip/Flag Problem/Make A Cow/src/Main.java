public class Main {

	public static void main(String[] args) {
		CowFrame c = new CowFrame();
		c.setDefaultCloseOperation(c.EXIT_ON_CLOSE);
		c.setVisible(true);
	}

}