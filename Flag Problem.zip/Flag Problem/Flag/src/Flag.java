import java.applet.Applet;
import java.awt.Graphics;

public class Flag extends Applet {
	
	public void paint (Graphics g) {
		g.drawString("Hello World!", 80, 80);
	}

}
